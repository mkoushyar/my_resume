wow = new WOW({
  boxClass:     'wow',      // default
  animateClass: 'animated', // default
  offset:       0,          // default
  mobile:       false,
  live:         true        // default
});
wow.init();
$(window).load(function () {
		$('#status').fadeOut(3000,function() {
			$('#preloader').fadeOut('slow', function() {
		});
	});
});
jQuery(document).ready(function($) {
	// Animated Scroll to Top Button
	var $scrollTop = $('.scroll-to-top-btn');
	if ($scrollTop.length > 0) {
		$(window).on('scroll', function(){
			if ($(window).scrollTop() > 600) {
				$scrollTop.addClass('visible');
			} else {
				$scrollTop.removeClass('visible');
			}
		});
	};
});
$(document).ready(function(){
	 $('.smobitrigger').smplmnu();
	 $('[data-toggle="tooltip"]').tooltip();
	 $("#menu-header li a,.scroll-to-top-btn").click(function() {
			 element = $(this).attr('href');
			 $('html, body').animate({
					 scrollTop: $(element).offset().top + 10
			 }, 1200);
			 if($('#menu-header').is(":visible") && $(window).width() < 769){
					 $('.navbar-toggle').trigger('click');
			 }
			 return false;
	 });

	 new Photostack( document.getElementById( 'photostack-3' ), {
 		callback : function( item ) {
 			//console.log(item)
 		}
 	} );
 	function EasyPeasyParallax() {
 		var	windowWidth = $(window).width();
 		if(windowWidth > 980){
 			scrollPos = $(this).scrollTop();
 			$('.parallax').not('.no-aminate').css({
 				'background-position' : '50%' + (-scrollPos/4)+"px"
 			});
 			var text = $('.text').not('.no-aminate');
 			text.css({
 				'margin-top': (scrollPos/4)+"px",
 				'opacity': 1-(scrollPos/250)
 			});
 			var opacityValue = text.css('opacity');
 			if(opacityValue == 0){
 				text.hide();
 			}else{
 				text.show();
 			}
 		}
 	}
 	function someResize(){
 		EasyPeasyParallax();
 		var	windowWidth = $(window).width(),
 			maxHeight = $('.near-big').height() - 42
 		if(windowWidth > 768){
 			$('.big-preview .thumb').css('height', maxHeight);
 		}
 		else{
 			$('.big-preview .thumb').css('height', 'auto');
 		}
 		if($('.colorbox').length){
 			$('a.colorbox').colorbox({
 				rel:'gal',
 				retinaImage: true,
 				opacity: 1,
 				current: false,
 				maxWidth: '95%',
 				maxHeight: '95%'
 			})
 		}
 	}
 	$(document).ready(function(){
 		someResize();

 		$('a[rel="popover"]').popover();
 		$('a[rel="tooltip"]').tooltip();
 		$('.carousel').carousel()


 		$(window).scroll(function() {
 			EasyPeasyParallax();
 			if ($(this).scrollTop() > 300) {
 				$('.goTop-link').fadeIn();
 			} else {
 				$('.goTop-link').fadeOut();
 			}
 		});

 		$('.goTop').on('click', function(){
 			$('body,html').animate({scrollTop: 0}, 1000);
 			return false;
 		});

 	});

 	$(window).resize(function(){
 		someResize();
 	});
	 $('.progress').each(function () {
			$(this).appear(function() {
			  $(this).animate({opacity:1,left:"-30px"},3000);
			    var b = $(this).find(".progress-bar").attr("data-width");
			  $(this).find(".progress-bar").animate({
				  width: b + "%"
			  }, 3000, "linear");
      });
	 });
});
$(document).ready(function () {
$("#contactForm").validator().on("submit", function(event) {
    if (event.isDefaultPrevented()) {
        formError();
        submitMSG(false, "Did you fill in the form properly?");
    } else {
        event.preventDefault();
        submitForm();
    }
});
function submitForm() {
    // var firstname = $("#firstname").val();
    // var phone = $("#phone").val();
    var email = $("#email").val();
    // var subject = $("#subject").val();
    // var message = $("#message").val();
    $.ajax({
        type: "POST",
        url: "php/contact.php",
        data: /*"#firstname=" + firstname + "&phone=" + phone + */"#email=" + email /*+ "&subject=" + subject + "&message=" + message */,
        success: function(text) {
            if (text == "success") {
                formSuccess();
            } else {
                formError();
                submitMSG(false, text);
            }
        }
    });
}
function formSuccess() {
    $("#eventform")[0].reset();
    submitMSG(true, "Message Submitted!")
}
function formError() {
    $("#contact").removeClass().addClass('shake animated').one(
        'webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend',
        function() {
            $(this).removeClass();
        });
}
function submitMSG(valid, msg) {
    if (valid) {
        var msgClasses = "h5 text-success";
    } else {
        var msgClasses = "h5 text-danger";
    }
    $("#msgSubmit").removeClass().addClass(msgClasses).text(msg);
}
});
